package com.byway.v2;

import com.byway.v1.RpcProxyClient;
import com.byway.api.TestService;
import com.byway.dto.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class V2ClientApp
{
    public static void main( String[] args )
    {
        ApplicationContext context=new AnnotationConfigApplicationContext(SpringConfig.class);
        RpcProxyClient proxyClient=context.getBean(RpcProxyClient.class);
        TestService testService=proxyClient.clientProxy(TestService.class,"localhost",6040);
        Object result=testService.sayHi("lihiming");
        System.out.println(result);
        Object result1=testService.saveUser(new User("lihiming",32));
        System.out.println(result1);
    }
}
