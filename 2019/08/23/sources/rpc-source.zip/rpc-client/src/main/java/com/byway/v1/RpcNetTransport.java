package com.byway.v1;

import com.byway.dto.RpcRequest;
import lombok.AllArgsConstructor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 15:54
 */
@AllArgsConstructor
public class RpcNetTransport {
    private String host;
    private int port;

    public Object send(RpcRequest request){
        Socket socket=null;
        ObjectInputStream objectInputStream=null;
        ObjectOutputStream objectOutputStream=null;
        Object result=null;
        try {
            socket=new Socket(host,port);
            objectOutputStream=new ObjectOutputStream(socket.getOutputStream());
            objectOutputStream.writeObject(request);
            objectOutputStream.flush();
            objectInputStream=new ObjectInputStream(socket.getInputStream());
            result=objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }finally {

                try {
                    if(objectInputStream!=null) {
                        objectInputStream.close();
                    }
                    if(objectOutputStream!=null) {
                        objectOutputStream.close();
                    }
                    if(socket!=null){
                        socket.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        return result;
    }

}
