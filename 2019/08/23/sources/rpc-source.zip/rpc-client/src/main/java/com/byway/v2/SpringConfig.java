package com.byway.v2;

import com.byway.v1.RpcProxyClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 18:36
 */
@Configuration
public class SpringConfig {

    @Bean
    public RpcProxyClient rpcProxyClient(){
        return new RpcProxyClient();
    }


}
