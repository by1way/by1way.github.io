package com.byway.v1;

import com.byway.api.TestService;
import com.byway.dto.User;

/**
 * Hello world!
 *
 */
public class V1ClientApp
{
    public static void main( String[] args )
    {
        RpcProxyClient proxyClient=new RpcProxyClient();
        TestService testService=proxyClient.clientProxy(TestService.class,"localhost",6040);
        Object result=testService.sayHi("lihiming");
        System.out.println(result);
        Object result1=testService.saveUser(new User("lihiming",32));
        System.out.println(result1);
    }
}
