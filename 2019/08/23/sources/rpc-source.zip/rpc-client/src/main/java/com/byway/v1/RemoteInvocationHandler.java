package com.byway.v1;

import com.byway.dto.RpcRequest;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 15:49
 */
public class RemoteInvocationHandler implements InvocationHandler {

    private String host;
    private int port;

    public RemoteInvocationHandler(String host, int port) {
        this.host = host;
        this.port = port;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("proxy com in ");
        RpcRequest request=new RpcRequest();
        request.setClassName(method.getDeclaringClass().getName());
        request.setMethodName(method.getName());
        request.setVersion("v2.0");
        request.setParams(args);

        RpcNetTransport transport=new RpcNetTransport(this.host,this.port);
        Object result=transport.send(request);
        return result;
    }
}
