package com.byway.v1;

import com.byway.api.TestService;
import com.byway.v1.service.TestServiceImpl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        TestService testService=new TestServiceImpl();
        RpcProxyServer rpcProxyServer=new RpcProxyServer();
        rpcProxyServer.publish(testService,6040);
    }
}
