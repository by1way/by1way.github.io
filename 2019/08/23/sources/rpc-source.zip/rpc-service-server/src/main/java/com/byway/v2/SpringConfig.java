package com.byway.v2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 17:45
 */
@Configuration
@ComponentScan(basePackages = "com.byway.v2")
public class SpringConfig {

    @Bean
    public RpcServer rpcServer(){
        return new RpcServer(6040);
    }
}
