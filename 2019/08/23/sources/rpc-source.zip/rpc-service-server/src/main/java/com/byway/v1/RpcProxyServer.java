package com.byway.v1;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 15:23
 */
public class RpcProxyServer {
    ExecutorService executorService= Executors.newCachedThreadPool();
    public void publish(Object service,int port){
        ServerSocket serverSocket=null;

        try {
            serverSocket=new ServerSocket(port);
            while(true){
                Socket socket=serverSocket.accept();
                executorService.execute(new ProcessorHandle(socket,service));
            }
        } catch (IOException  e) {
            e.printStackTrace();
        }finally {
            try {
                if(serverSocket!=null)
                    serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
