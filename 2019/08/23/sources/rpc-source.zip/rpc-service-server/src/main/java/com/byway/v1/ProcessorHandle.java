package com.byway.v1;

import com.byway.dto.RpcRequest;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Socket;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 15:29
 */
public class ProcessorHandle implements Runnable {

    private Socket socket;

    private Object service;

    public ProcessorHandle(Socket socket, Object service) {
        this.socket = socket;
        this.service=service;
    }

    @Override
    public void run() {
        ObjectOutputStream outputStream=null;
        ObjectInputStream inputStream=null;
        try {
            inputStream=new ObjectInputStream(socket.getInputStream());
            RpcRequest rpcRequest=(RpcRequest)inputStream.readObject();//输入流中包含：class method param
            Object result=invoke(rpcRequest);
            outputStream=new ObjectOutputStream(socket.getOutputStream());
            outputStream.writeObject(result);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }finally {

                try {
                    if(inputStream!=null) {
                        inputStream.close();
                    }
                    if(outputStream!=null){
                        outputStream.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
    }

    private Object invoke(RpcRequest request) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Object[] args=request.getParams();
        Class<?>[] types=new Class[args.length];
        for(int i=0;i<args.length;i++){
            types[i]=args[i].getClass();
        }
        Class clazz=Class.forName(request.getClassName());
        Method method=clazz.getMethod(request.getMethodName(),types);
        Object result=method.invoke(this.service,args);
        return result;
    }


}
