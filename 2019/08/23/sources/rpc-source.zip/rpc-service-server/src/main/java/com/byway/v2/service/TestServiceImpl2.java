package com.byway.v2.service;

import com.byway.api.TestService;
import com.byway.dto.User;
import com.byway.v2.RpcService;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 14:36
 */
@RpcService(value = TestService.class,version = "v2.0")
public class TestServiceImpl2 implements TestService {

    @Override
    public String sayHi(String name) {
        System.out.println("【v2.0】request in sayHi:"+name);
        return "【v2.0】hi,my "+name;
    }

    @Override
    public String saveUser(User user) {
        System.out.println("【v2.0】request in saveUser:"+user);
        return "【v2.0】SUCCESS";
    }
}
