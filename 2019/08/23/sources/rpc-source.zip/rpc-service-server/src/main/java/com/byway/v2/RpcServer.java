package com.byway.v2;

import com.byway.v2.ProcessorHandle;
import org.nutz.lang.Strings;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 17:43
 */
@Component
public class RpcServer implements ApplicationContextAware, InitializingBean {

    private int port;

    private Map<String,Object> handleMap=new HashMap<>();

    public RpcServer(int port) {
        this.port = port;
    }

    ExecutorService executorService= Executors.newCachedThreadPool();

    @Override
    public void afterPropertiesSet() throws Exception {
        ServerSocket serverSocket=null;
        try {
            serverSocket=new ServerSocket(port);
            while(true){
                Socket socket=serverSocket.accept();
                executorService.execute(new ProcessorHandle(socket,handleMap));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(serverSocket!=null)
                    serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
       Map<String,Object> serviceBeanMap= applicationContext.getBeansWithAnnotation(RpcService.class);
       if(!serviceBeanMap.isEmpty()){
           for (Object serviceBean:serviceBeanMap.values()) {
               RpcService rpcService=serviceBean.getClass().getAnnotation(RpcService.class);
               String serviceName=rpcService.value().getName();
               String version=rpcService.version();
               if(!Strings.isBlank(version)){
                   serviceName+="_"+version;
               }
               handleMap.put(serviceName,serviceBean);
           }
       }


    }
}
