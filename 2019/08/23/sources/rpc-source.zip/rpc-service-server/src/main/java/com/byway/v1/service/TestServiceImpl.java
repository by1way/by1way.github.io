package com.byway.v1.service;

import com.byway.api.TestService;
import com.byway.dto.User;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 14:36
 */
public class TestServiceImpl implements TestService {

    @Override
    public String sayHi(String name) {
        System.out.println("request in sayHi:"+name);
        return "hi,my "+name;
    }

    @Override
    public String saveUser(User user) {
        System.out.println("request in saveUser:"+user);
        return "SUCCESS";
    }
}
