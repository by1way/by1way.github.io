package com.byway.v2.service;

import com.byway.api.TestService;
import com.byway.dto.User;
import com.byway.v2.RpcService;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 14:36
 */
@RpcService(value = TestService.class,version = "v1.0")
public class TestServiceImpl implements TestService {

    @Override
    public String sayHi(String name) {
        System.out.println("【v1.0】request in sayHi:"+name);
        return "【v1.0】hi,my "+name;
    }

    @Override
    public String saveUser(User user) {
        System.out.println("【v1.0】request in saveUser:"+user);
        return "【v1.0】SUCCESS";
    }
}
