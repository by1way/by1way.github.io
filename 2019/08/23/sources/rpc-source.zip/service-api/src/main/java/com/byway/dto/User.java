package com.byway.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 14:58
 */
@Data
@AllArgsConstructor
@ToString
public class User implements Serializable {

    private String name;

    private Integer age;
}
