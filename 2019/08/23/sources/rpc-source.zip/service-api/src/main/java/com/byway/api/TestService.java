package com.byway.api;

import com.byway.dto.User;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 14:58
 */
public interface TestService {

    public String sayHi(String name);

    public String saveUser(User user);
}
