package com.byway.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author lihaiming
 * @version 1.0
 * @date 2020/4/5 15:33
 */
@Data
public class RpcRequest implements Serializable {

    private String className;

    private String methodName;

    private String version;

    private Object[] params;
}
